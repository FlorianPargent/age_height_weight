This repository contains all materials for the manuscript titled: "Item Construction Rules Revisited: Learnings from Measurement of Latent Variables with Gold Standard Items"

A Quarto Manuscripts website presenting the manuscript and electronic supplementary materials is hosted at <https://florianpargent.github.io/gold-standard-items/.>
